<?php
$ngentot = file_get_contents('../ajax/kontol.txt');
echo $ngentot;
?>