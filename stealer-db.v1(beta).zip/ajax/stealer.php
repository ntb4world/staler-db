<?php
require '../fungsi.php';

$keyword = $_GET["keyword"];
$query = "SELECT * FROM data_stealer
			WHERE
		nama LIKE '%$keyword%' OR
		link_fb LIKE '%$keyword%' ORDER BY id DESC
		";
$stealer = query($query);
?>
	<br>
	<table border="1" cellpadding="10" cellspacing="0">
	<tr>
		<th>No.</th>
		<th>Nama</th>
		<th>Link Facebook</th>
		<th>Reason</th>
	</tr>
	<?php $i = 1; ?>
	<?php foreach ($stealer as $result) : ?>
	<tr>
		<td><?= $i ?></td>
		<td><?= $result["nama"] ?></td>
		<td><a href=""><?= $result["link_fb"] ?></a></td>
		<td><?= $result["reason"] ?></td>
	</tr>
	<?php $i++ ?>
	<?php endforeach; ?>
	</table>