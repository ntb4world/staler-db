<?php

$koneksi = mysqli_connect("localhost", "root", "", "stealer");

function query($query) {
	global $koneksi;
	$result = mysqli_query($koneksi, $query);
	$rows = [];
	while ( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

function cari($keyword) {
	$query = "SELECT * FROM data_stealer
				WHERE
				nama LIKE '%$keyword%' OR
				link_fb LIKE '%$keyword%'
				";
	return query($query);
}

?>