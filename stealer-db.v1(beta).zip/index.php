<?php
require 'fungsi.php';
$stealer = query("SELECT * FROM data_stealer ORDER BY id desc");

if (isset($_POST["cari"])) {
	$stealer = cari($_POST["keyword"]);
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>StealerDB | ntb4world</title>
		<!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->
		<style>
			.form-control{
				margin-top: -18px;
			}
		</style>
	</head>
	<body>
		<header>
			<center><h1>WELCOME TO STEALER-DB</h1></center>
			<h3>Blacklist Stealer :</h3>
		</header>
		<form action="" method="post" class="form-control">
			<input type="text" name="keyword" size="30" autofocus autocomplete="off" placeholder="Cari Stealer.." id="keyword">
			<button type="submit" name="cari" id="tombol-cari">Cari!!</button>
		</form>
		<!-- <br> -->
		<div id="container">
			<br>
			<table border="1" cellpadding="10" cellspacing="0">
				<tr>
					<th>No.</th>
					<th>Nama</th>
					<th>Link Facebook</th>
					<th>Reason</th>
				</tr>
				<?php $i = 1; ?>
				<?php foreach ($stealer as $result) : ?>
				<tr>
					<td><?= $i ?></td>
					<td><?= $result["nama"] ?></td>
					<td><a href=""><?= $result["link_fb"] ?></a></td>
					<td><?= $result["reason"] ?></td>
				</tr>
				<?php $i++ ?>
				<?php endforeach; ?>
			</table>
		</div>

		<script type="text/javascript" src="js/script.js"></script>
	</body>
</html>